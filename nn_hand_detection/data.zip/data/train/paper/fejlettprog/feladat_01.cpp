#include <iostream>

using namespace std;

class VilagitoDisz {
private:
    unsigned fenyesseg;
    bool bekapcsolva = false;

public:
    VilagitoDisz(unsigned fenyesseg = 0): fenyesseg(fenyesseg) {}

    VilagitoDisz(const VilagitoDisz& other) {
        fenyesseg = other.fenyesseg;
        bekapcsolva = other.bekapcsolva;
    }

    VilagitoDisz& operator++(void) {
        bekapcsolva = true;
        return *this;
    }

    VilagitoDisz& operator--(void) {
        bekapcsolva = false;
        return *this;
    }

    unsigned get_fenyesseg() {
        return bekapcsolva ? fenyesseg : 0;
    }

    bool is_bekapcsolva() {
        return bekapcsolva;
    }
};

class KisKaracsonyfa {
private:
    VilagitoDisz* csucs_disz;
    string fa_tipus;

public:
    KisKaracsonyfa(string tipus = "luc"): fa_tipus(tipus), 
                                          csucs_disz(nullptr) {}

    
    KisKaracsonyfa(const KisKaracsonyfa& other) {
        fa_tipus = other.fa_tipus;

        if (other.csucs_disz != nullptr) {
            csucs_disz = new VilagitoDisz(*other.csucs_disz);
        } else {
            csucs_disz = nullptr;
        }
    }
    
    KisKaracsonyfa& operator=(const KisKaracsonyfa& other) {
        if (csucs_disz != nullptr) delete csucs_disz;
        fa_tipus = other.fa_tipus;
        if (other.csucs_disz != nullptr) {
            csucs_disz = new VilagitoDisz(*other.csucs_disz);
        } else {
            csucs_disz = nullptr;
        }
        return *this;
    }

    ~KisKaracsonyfa() {
        if (csucs_disz != nullptr) {
            delete csucs_disz;
        }
    }

    void disz_felhelyezese(const VilagitoDisz& disz) {
        if (csucs_disz != nullptr) delete csucs_disz;
        csucs_disz = new VilagitoDisz(disz);
    }

    void bekapcsol() {
        if (csucs_disz != nullptr) {
            ++(*csucs_disz);
        }
    }
    
    void kikapcsol() {
        if (csucs_disz != nullptr) {
            --(*csucs_disz);
        }
    }

    unsigned get_fenyesseg() {
        if (csucs_disz != nullptr) {
            return csucs_disz->get_fenyesseg();
        }
        return 0;
    }
};

class NagyKaracsonyfa {
private:
    VilagitoDisz* diszek;
    unsigned diszek_szama;
    unsigned act = 0;

public:
    NagyKaracsonyfa(unsigned diszek_szama): diszek_szama(diszek_szama) {
        diszek = new VilagitoDisz[diszek_szama];
    }

    NagyKaracsonyfa(NagyKaracsonyfa& other) {
        diszek_szama = other.diszek_szama;
        act = other.act;
        diszek = new VilagitoDisz[diszek_szama];
        for (int i = 0; i < act; i++) {
            diszek[i] = other.diszek[i];
        }
    }

    ~NagyKaracsonyfa() {
        delete[] diszek;
    }

    NagyKaracsonyfa& operator=(NagyKaracsonyfa& other) {
        delete[] diszek;

        diszek_szama = other.diszek_szama;
        act = other.act;
        diszek = new VilagitoDisz[diszek_szama];
        for (int i = 0; i < act; i++) {
            diszek[i] = other.diszek[i];
        }

        return *this;
    }

    void disz_felhelyezese(VilagitoDisz& disz) {
        if (act < diszek_szama) {
            diszek[act++] = disz;
        }
    }

    void bekapcsol() {
        for (int i = 0; i < act; i++) {
            ++diszek[i];
        }
    }

    void kikapcsol() {
        for (int i = 0; i < act; i++) {
            --diszek[i];
        }
    }

    unsigned get_fenyesseg() {
        unsigned sum = 0;
        for (int i = 0; i < act; i++) {
            sum += diszek[i].get_fenyesseg();
        }
        return sum;
    }
};

int main(int argc, char const *argv[]) {
    
    return 0;
}
