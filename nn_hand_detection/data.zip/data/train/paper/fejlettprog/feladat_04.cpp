#include <iostream>
#include <string>

using namespace std;

#ifndef TEST_BIRO
#  define TRAITS_CONFIGURATIONS
#endif

#ifdef TRAITS_CONFIGURATIONS

struct AMD {
  const string processor = "AMD";
  const string tipus;
  AMD(const string& tipus) : tipus(tipus) {
  }
};

struct Intel {
  const string processor = "Intel";
  const string tipus;
  Intel(const string& tipus) : tipus(tipus) {
  }
};

template<class>
struct Asus_A_123;

template<>
struct Asus_A_123<AMD> {
  const string alaplap = "Asus_A_123";;
  const bool kompatibilis = true;
};

template<>
struct Asus_A_123<Intel> {
  const string alaplap = "Asus_A_123";
  const bool kompatibilis = false;
};

template<class>
struct Gigabyte_I_789;

template<>
struct Gigabyte_I_789<AMD> {
  const string alaplap = "Gigabyte_I_789";
  const bool kompatibilis = false;
};

template<>
struct Gigabyte_I_789<Intel> {
  const string alaplap = "Gigabyte_I_789";
  const bool kompatibilis = true;
};

struct HDD {
  const string tipus = "HDD";
  const unsigned kapacitas;
  HDD(unsigned kapacitas = 500) : kapacitas(kapacitas) {
  }
};

struct SSD {
  const string tipus = "SSD";
  const unsigned kapacitas;
  SSD(unsigned kapacitas = 500) : kapacitas(kapacitas) {
  }
};

// TODO
template<typename>
class konfiguracio_ajanlas;

template<>
class konfiguracio_ajanlas<AMD> {
public:
    typedef Asus_A_123<AMD> alaplap_tipus;
    typedef HDD hattertar_tipus;
};

template<>
class konfiguracio_ajanlas<Intel> {
public:
    typedef Gigabyte_I_789<Intel> alaplap_tipus;
    typedef SSD hattertar_tipus;
};

template<typename processzor, typename konfig = konfiguracio_ajanlas<processzor>>
class szamitogep {
private:
    typedef typename konfig::alaplap_tipus alaplap_tipus;
    typedef typename konfig::hattertar_tipus hattertar_tipus;
    
    processzor p;
    alaplap_tipus alaplap;
    hattertar_tipus hattertar;

public:
    szamitogep(processzor p, hattertar_tipus ht): p(p), hattertar(ht) {}

    szamitogep(const string s, int c): p(s), hattertar(c) {}

    bool ervenyes_konfiguracio() const {
        return alaplap.kompatibilis;
    }

    friend ostream& operator<<(ostream& os, szamitogep sz) {
        os << "processor: " << sz.p.processor << " (" << sz.p.tipus << ")" << endl;
        os << "alaplap: " << sz.alaplap.alaplap << endl;
        os << "hattertar: " << sz.hattertar.tipus << " (" << sz.hattertar.kapacitas << ")" << endl;
        return os;
    }
};

// ---------- Test ---------

void test_config() {
  AMD amd("AM4 Ryzen 7 3800X");
  Intel intel("Core i9-9900K");
  
//   szamitogep<AMD> sz_amd(amd, HDD(250));
  szamitogep<AMD> sz_amd(amd, HDD(250));
  cout << sz_amd << endl;
  
  szamitogep<Intel> sz_intel("Intel", 500);
  cout << sz_intel << endl;

  cout << sz_intel.ervenyes_konfiguracio() << endl;
}
/*
processor: AMD (AM4 Ryzen 7 3800X)
alaplap: Asus_A_123
hattertar: HDD (250)

processor: Intel (Core i9-9900K)
alaplap: Gigabyte_I_789
hattertar: SSD (500)

*/

#endif // TRAITS_CONFIGURATIONS


#ifndef TEST_BIRO

int main() {
#ifdef TRAITS_CONFIGURATIONS
  test_config();
#endif
}

#endif // TEST_BIRO
