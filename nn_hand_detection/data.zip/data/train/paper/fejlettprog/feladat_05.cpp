#include <iostream>
#include <map>
#include <stack>
#include <string>
#include <sstream>

using namespace std;


// Lokalis teszteleshez ...
#ifndef TEST_BIRO
#  define MANIPULATOR_BACKWARD
#  define MANIPULATOR_WRITE_BRACKET
#  define MANIPULATOR_COUT_CERR
#  define EFFECTOR_DOUBLE_SPACE
#  define EFFEKTOR_REPEAT
#  define EFFEKTOR_CENSURE
#endif


#ifdef MANIPULATOR_BACKWARD

namespace A {
  stringstream ss;
  ostream *os_other;
  ostream& backward_begin(ostream &os) {
    os_other = &os;
    ss.str("");
    return ss;
  }

  ostream& backward_end(ostream &os) {
    string str(ss.str());
    for (auto it = str.rbegin(); it != str.rend(); it++)
      (*os_other) << *it;
    return *os_other;
  }
}

namespace B {
  stringstream s;
  streambuf *psb;

  ostream& backward_begin(ostream &os) {
    s.str("");
    psb = os.rdbuf(s.rdbuf());
    return os;
  }

  ostream& backward_end(ostream &os) {
    os.rdbuf(psb);
    string str = s.str();
    for (auto it = str.rbegin(); it != str.rend(); it++)
      os << *it;
    return os;
  }
}

namespace C {
  stack< pair<stringstream *, streambuf *> > st;

  ostream& backward_begin(ostream &os) {
    stringstream *s = new stringstream;
    streambuf *psb = os.rdbuf(s->rdbuf());
    st.push(make_pair(s, psb));
    
    return os;
  }

  ostream& backward_end(ostream &os) {
    if (st.empty())
      return os; // or throw exception();
   
    os.rdbuf(st.top().second);
    string str = st.top().first->str();
    delete st.top().first;
    st.pop();

    for (auto it = str.rbegin(); it != str.rend(); it++)
      os << *it;
    return os;
  }
}

namespace D {
  map<ostream*, stack< pair<stringstream *, streambuf *> > > os_m;

  ostream& backward_begin(ostream &os) {
    stringstream *s = new stringstream;
    streambuf *psb = os.rdbuf(s->rdbuf());
    os_m[&os].push(make_pair(s, psb));
    
    return os;
  }

  ostream& backward_end(ostream &os) {
    auto it = os_m.find(&os);
    if (it == os_m.end()) // hibakezeles
      return os;

    os.rdbuf(it->second.top().second);
    string str = it->second.top().first->str();
    delete it->second.top().first;
    it->second.pop();

    for (auto it = str.rbegin(); it != str.rend(); it++)
      os << *it;

    return os;
  }
}


void test_backward_a() {
  cout << endl << "backward a test: " << endl;
  cout << A::backward_begin << "something" << A::backward_end << endl;
}

void test_backward_b() {
  cout << endl << "backward b test: " << endl;
  cout << B::backward_begin;
  cout << "something" << ' ' << 123 << ' ' << 'a';
  cout << B::backward_end << endl;
}

void test_backward_c() {
  cout << endl << "backward c test: " << endl;
  cout << C::backward_begin;
  cout << " 9 8 7 ";
  cout << C::backward_begin;
  cout << " 4 5 6 ";
  cout << C::backward_end;
  cout << " 3 2 1 ";
  cout << C::backward_end << endl;
}

void test_backward_d() {
  cout << endl << "backward d test: " << endl;
  cout << "[cout: ]" << D::backward_begin;
  cout << "[ a b c ]";

  cerr << "<cerr: >" << D::backward_begin;
  cerr << "<1 2 3 >" << "< >" << 456 << "< 7 8 9>";

  stringstream ss;
  ss << "(sstream: 1 2 3)" << D::backward_begin << "( -s- +s+ )";

  cout << D::backward_begin;
  cout << "[ I II III ]";
  cout << D::backward_end;
  cout << "[ A B C]";
  cout << D::backward_end << endl;

  cerr << "<f g>" << D::backward_end << endl;
  ss << "( 1 2 3 )" << D::backward_end << "( end )";
  cout << ss.str() << endl;
}
#endif // MANIPULATOR_BACKWARD



#ifdef MANIPULATOR_WRITE_BRACKET

ostream& write_bracket(ostream& os) {
  static int left = 1;
  return os << "()"[left = 1 - left];
#if 0
  static char par = ')';
  return os << (par = '(' + ')' - par);
#endif
}

// ---------- Test ---------

void test_bracket() {
  cout << endl << "bracket test: " << endl;
  cout << "  " << write_bracket << " test " << write_bracket << endl;
  cout << "  " << write_bracket << " ... " << write_bracket << "  "
       << write_bracket << " ) ... ( " << write_bracket << endl;
}
#endif // MANIPULATOR_WRITE_BRACKET



#ifdef MANIPULATOR_COUT_CERR

ostream& cout_cerr(ostream& os) {
  if (&os == &cout || &os == &cerr)
    cout.rdbuf(cerr.rdbuf(cout.rdbuf()));
  return os;
}

// ---------- Test ---------

void test_cout_cerr() {
  cout << endl << "cout-cerr test:" << endl;
  cout << "De jo lenne " << cout_cerr << "5-ost kapni";
  cerr << "megbukni" << endl << cout_cerr << " nem szeretnek" << endl;
}
#endif // MANIPULATOR_COUT_CERR 



#ifdef EFFECTOR_DOUBLE_SPACE

class double_space {
  string s;
public:
  double_space(const string& s) : s(s) {
  }

  friend ostream& operator<<(ostream &os, const double_space &b) {
    for (const auto &c : b.s)
      os << (c == ' ' ?  " " : "") << c;
    return os;
  }
};

// ---------- Test ---------

void test_double_space() {
  cout << endl << "double space test:" << endl;
  cout << double_space("ebbennincszokoz\t123") << endl;
  cout << double_space("egy space,  ket  space") << endl;
  cout << double_space("Sikerult megoldani  a   feladatot :)") << endl;
}
#endif // MANIPULATOR_DOUBLE_SPACE



#ifdef EFFEKTOR_REPEAT

class repeat {
  string str;
public:
  template<class T> 
  repeat(const T& t, unsigned n) {
    stringstream s;
    for (unsigned i = 0; i < n; i++)
      s << t;
    str = s.str();
  }

  friend ostream& operator<<(ostream& os, const repeat& cw) {
    return os << cw.str;
  }
};

// ---------- Test ---------

struct repeat_test {
  string s;
  friend ostream& operator<<(ostream& os, const repeat_test& rt) {
    return os << rt.s;
  }
};

void test_repeat() {
  cout << endl << "repeat test: " << endl;
  cout << "  " << repeat('a', 10) << endl;
  cout << "  " << repeat("Bora ", 2) << endl;
  cout << "  " << repeat(15, 8) << endl;
  cout << "  " << repeat(repeat_test{"repeat_test "}, 3) << endl;
}
#endif // EFFEKTOR_REPEAT



#ifdef EFFEKTOR_CENSURE

class censure {
  string text, cen, ntext;
public:
  censure(const string& t, const string& c, const string& n) : text(t), cen(c), ntext(n) {
  }

  friend ostream& operator<<(ostream& os, const censure& c) {
    if (c.cen.length() != c.ntext.length())
      return os << "hiba";

    const size_t len = c.cen.length();
    string tmp = c.text;
    for (size_t pos = 0; pos < tmp.length() && (pos = tmp.find(c.cen, pos)) != string::npos; pos += len)
      tmp = tmp.replace(pos, len, c.ntext);

    return os << tmp;
  }
};

// ---------- Test ---------

void test_censure() {
  cout << endl << "censure test: " << endl;
  cout << "  " << censure("szilvafa szilvalekvar szilvap*linka", "szilva", "barack") << endl;
  cout << "  " << censure("--- aaaaaaaa ---", "a", "b") << endl;
  cout << "  " << censure("azaz azaz azaz", "az", "ma") << endl;
  cout << "  " << censure("aaaaaaaa", "a", "bb") << endl;
}
#endif // EFFEKTOR_CENSURE



#ifndef TEST_BIRO

int main() {
#ifdef MANIPULATOR_BACKWARD
  test_backward_a();
  test_backward_b();
  test_backward_c();
  test_backward_d();
#endif
  
#ifdef MANIPULATOR_WRITE_BRACKET
  test_bracket();
#endif

#ifdef MANIPULATOR_COUT_CERR
  test_cout_cerr();
#endif

#ifdef EFFECTOR_DOUBLE_SPACE
  test_double_space();
#endif
 
#ifdef EFFEKTOR_REPEAT
  test_repeat();
#endif

#ifdef EFFEKTOR_CENSURE
  test_censure();
#endif
}

#endif // NO_MAIN
