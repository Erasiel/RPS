#include <iostream>
#include <string>

using namespace std;

ostream& write_bracket(ostream& os) {
    static bool ayylmao = true;
    if (ayylmao) {
        os << "(";
    } else {
        os << ")";
    }
    ayylmao = !ayylmao;
    return os;
}

ostream& cout_cerr(ostream& os) {
    if (&os == &cout || &os == &cerr) {
        streambuf* temp = cout.rdbuf();
        cout.rdbuf(cerr.rdbuf());
        cerr.rdbuf(temp);
    }
    return os;
}

struct double_space {
    string alma;
    double_space(string a): alma(a) {}
    friend ostream& operator<<(ostream& os, const double_space& ds) {
        for (int i = 0; i < ds.alma.length(); i++) {
            if (ds.alma[i] == ' ') {
                os << "  ";
            } else {
                os << ds.alma[i];
            }
        }
        return os;
    }
};

namespace repeat{
struct repeat {
    string retek;
    unsigned n;

    repeat(int a, unsigned n): n(n) {
        retek = to_string(a);
    }
    
    repeat(char a, unsigned n): n(n) {
        retek = a;
    }
    
    repeat(string a, unsigned n): n(n) {
        retek = a;
    }

    friend ostream& operator<<(ostream& os, const repeat& asd) {
        for (unsigned i = 0; i < asd.n; i++) {
            os << asd.retek;
        }
        return os;
    }
};
}

// int main(int argc, char const *argv[]) {

//     cout << repeat("asd", 3) << endl;
//     cout << repeat('a', 3) << endl;
//     cout << repeat(123, 3) << endl;

//     return 0;
// }
