#include <iostream>
#include <string>
#include <vector>

using namespace std;

#ifndef TEST_BIRO
#define ITERATOR_STRINGS
#endif

#ifdef ITERATOR_STRINGS

class strings {
    vector<string> v;
    string uristenverybig;

    class iterator {
    private:
        char* _p;

        friend class strings;

        iterator(char* cp): _p(cp) {}

    public:
        iterator() : _p(nullptr) {
        }
        
        iterator(const iterator &it) : _p(it._p) { // nem kellene
        }

        char& operator*() {
            return *_p;
        }

        iterator& operator++() {
            ++_p;
            return *this;
        }

        iterator operator++(int) {
            iterator temp(*this);
            operator++();
            return temp;
        }

        bool operator==(const iterator &it) {
            return _p == it._p;
        }
        
        bool operator!=(const iterator &it) {
            return !(*this == it);
        }
    };

    void ujra_baszat() {
        uristenverybig = "";
        for (string s: v) 
            uristenverybig.append(s);
    }

public:
    void add(const string &s) {
        v.push_back(s);
        uristenverybig.append(s);
    }

    void remove() {
        if (v.empty())
            throw out_of_range("empty");
        v.pop_back();
        ujra_baszat();
    }

    void remove(size_t index) {
        if (v.size() <= index)
            throw out_of_range("remove: " + to_string(index));
        v.erase(v.begin() + index);
        ujra_baszat();
    }

    const string &operator[](size_t index) const {
        if (index < v.size())
            return v[index];
        throw out_of_range("operator[] const: " + to_string(index));
    }

    string &operator[](size_t index) {
        if (index < v.size())
            return v[index];
        throw out_of_range("operator[]: " + to_string(index));
    }

    friend ostream &operator<<(ostream &os, const strings &s) {
        for (const auto &i : s.v)
            os << i;
        return os;
    }

    friend ostream &operator,(ostream &os, const strings &s) {
        for (const auto &i : s.v)
            os << "'" << i << (&i != &s.v.back() ? "', " : "'");
        return os;
    }

    iterator begin() {
        return iterator(&(uristenverybig[0]));
    }

    iterator end() {
        return iterator(&(uristenverybig[uristenverybig.length()]));
    }

};

// ----- test ------
#ifndef TEST_BIRO

void test_strings() {
    cout << endl
         << "strings iterator test:" << endl;
    strings strs;
    strs.add("1");
    strs.add("2");
    strs.add("3");
    strs.add("4");
    strs.add("56789");
    strs.add("abcd");

    cout << strs << endl;
    (cout, strs) << endl;
    for (auto it = strs.begin(); it != strs.end(); it++)
        cout << *it << " ";
    cout << endl
         << endl;

    strs.remove(2);
    cout << strs << endl;
    (cout, strs) << endl
                 << endl;
    for (auto it = strs.begin(); it != strs.end(); ++it)
        cout << *it << " ";
    cout << endl
         << endl;
}

#endif // TEST_BIRO
#endif // ITERATOR_STRINGS

#ifndef TEST_BIRO
int main() {

#ifdef ITERATOR_STRINGS
    test_strings();
#endif
}
#endif // TEST_BIRO
