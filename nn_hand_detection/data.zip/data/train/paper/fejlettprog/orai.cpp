#include <iostream>

using namespace std;

class Hallgato {
    string nev, kod;

public:
    Hallgato(const string& nev, const string& kod): nev(nev), kod(kod) {
    }
    
    const string& get_nev() const {
        return nev;
    }
    
    void set_nev(const string& nev) {
        this->nev = nev;
    }
    
    const string& get_kod() const {
        return kod;
    }
    
    void set_kod(const string& kod) {
        this->kod = kod;
    }
    friend ostream& operator<<(ostream& stream, const Hallgato& hallgato) {
        return stream << "neve: " << hallgato.nev << ", kodja: " << hallgato.kod;
    }
};


class Kurzus {
    string nev, kod;
    size_t max, act = 0;
    Hallgato **hallgatok;
public:
    Kurzus(const string& nev, const string& kod, size_t max) :
        nev(nev), kod(kod), max(max), hallgatok(new Hallgato*[max]) {
    }
    
    ~Kurzus() {
        delete[] hallgatok;
    }
    
    Kurzus(const Kurzus& k) :
        nev(k.nev), kod(k.kod), max(k.max), act(k.act), hallgatok(new Hallgato*[max])
    {
        for (size_t i = 0; i < act; i++)
            hallgatok[i] = k.hallgatok[i];
    }
    
    Kurzus& operator=(const Kurzus& k) {
        if (this == &k)
            return *this;
        
        nev = k.nev;
        kod = k.kod;
        max = k.max;
        act = k.act;
        delete[] hallgatok;
        hallgatok = new Hallgato* [max];
        for (size_t i = 0; i < act; i++)
            hallgatok[i] = k.hallgatok[i];
        return *this;
    }
    
    Kurzus& operator+=(Hallgato& h) {
        if (max <= act)
            throw act;
        hallgatok[act++] = &h;
        return *this;
    }
    
    Kurzus operator+(Hallgato& h) const {
        Kurzus k = *this;
        k += h;
        return k;
    }
    
    const Hallgato& operator[](size_t i) const {
        if (i < act)
            return *hallgatok[i];
        throw i;
    }
    
    // pre
    Kurzus& operator++() {
        ++max;
        Hallgato **tmp = new Hallgato*[max];
        for (size_t i = 0; i < act; i++)
            tmp[i] = hallgatok[i];
        delete[] hallgatok;
        hallgatok = tmp;
        return *this;
    }
    // post
    Kurzus operator++(int) {
        Kurzus k = *this;
        operator++();
        return k;
    }
    
    friend ostream& operator<<(ostream& os, const Kurzus& k) {
        os << "nev: " << k.nev << ", kod: " << k.kod << ", act: " << k.act <<
           ", max: " << k.max << endl;
        for (size_t i = 0; i < k.act; i++)
            os << "  " << *k.hallgatok[i] << endl;
        return os;
    }
    
};

int main() {
    Hallgato h1("Almafa Aladar Adonisz", "ASDASD");
    //cout << h1 << endl;
    Kurzus k("FP", "FP123", 10);
    k += h1;
    cout << k[0] << endl;
    cout << k << endl;
    ++k;
    cout << k << endl;
    cout << (k++) << endl;
    cout << k << endl;
    

}
