#include <iostream>

using namespace std;

template<typename T, size_t N>
class Vector {
private:
    T vec[N];
public:
    Vector() {
        for (int i = 0; i < N; i++) {
            vec[i] = T();
        }
    };
    
    Vector(const T* arr) {
        for (int i = 0; i < N; i++) {
            vec[i] = arr[i];
        }
    }

    const T& operator[](const int i) const {
        if (0 <= i && i < N) {
            return vec[i];
        }
        throw (size_t) i;
    }

    friend ostream& operator<<(ostream& os, const Vector& v) {
        for (int i = 0; i < N - 1; i++) {
            os << v[i] << ", ";
        }
        os << v[N - 1] << endl;
        return os;
    }

    template<size_t M>
    Vector<T, N + M> operator+(const Vector<T, M>& v) const {
        T temp[N + M];
        for (int i = 0; i < N; i++) {
            temp[i] = vec[i];
        }

        for (int i = 0; i < M; i++) {
            temp[N + i] = v[i];
        }

        Vector<T, N + M> res(temp);
        return res;
    }
};

template<typename T, size_t N>
size_t remove_larger(T* arr, T limit) {
    size_t over_limit = 0;
    T temp[N];
    int t_i = 0;

    for (int i = 0; i < N; i++) {
        if (arr[i] > limit) {
            over_limit++;
        } else {
            temp[t_i++] = arr[i];
        }
    }

    for (int i = 0; i < t_i; i++) {
        arr[i] = temp[i];
    }

    return N - over_limit;
}

template<>
size_t remove_larger<int, 10>(int* arr, int limit) {
    size_t equals_limit = 0;
    int temp[10];
    int t_i = 0;

    for (int i = 0; i < 10; i++) {
        if (arr[i] == limit) {
            equals_limit++;
        } else {
            temp[t_i++] = arr[i];
        }
    }

    for (int i = 0; i < t_i; i++) {
        arr[i] = temp[i];
    }

    return 10 - equals_limit;
}

int main(int argc, char const *argv[]) {
    int arr[5] = {1, 2, 3, 4, 5};
    const Vector<int, 5> vec(arr);

    int arr2[4] = {6, 7, 8, 9};
    const Vector<int, 4> vec2(arr2);

    cout << vec + vec2;

    int arr3[5] = {3, 2, 1, 1, 1};
    int a = remove_larger<int, 5>(arr3, 1);
    for (int i = 0; i < 5; i++) {
        cout << arr3[i] << " ";
    }
    cout << endl << a << endl;

    return 0;
}
