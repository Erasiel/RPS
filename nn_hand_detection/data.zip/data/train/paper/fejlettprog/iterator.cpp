// Iterator
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

// vektor sablon, amely megvalositja a belso iterator osztalyt
template<class T, size_t N>
class Vector {
  T data[N];
public:

  // iterator belso osztaly
  class iterator {
  public:
    iterator() : _p(nullptr) {
    }
    
    iterator(const iterator &it) : _p(it._p) { // nem kellene
    }
    
    // dereferencia
    T& operator*() {
      return *_p;
    }
    T* operator->() {
      return _p;
    }
    
    // prefix iterator lepteto
    iterator& operator++() {
      ++_p;
      return *this;
    }
    
    // postfix iterator lepteto
    iterator operator++(int) {
      iterator temp(*this);
      operator++();
      return temp;
    }
    
    bool operator==(const iterator &it) {
      return _p == it._p;
    }
    bool operator!=(const iterator &it) {
      return !(*this == it);
    }
  private:
    iterator(T *p) : _p(p) { } // privat konstruktor, ami a megfelelo elemre allitja az iteratort
    T *_p;                     // az iterator altal hivatkozott elem
    friend class Vector<T,N>;  // Vector sablon friend definicioja, hogy elerje a privat konstruktort
  };

  // iterator eloallitasa, ami a vektor elso elemere mutat
  iterator begin() {
    return iterator(data);
  }
  // iterator eloallitasa, ami a vektor utolso eleme utani poziciora mutat
  iterator end() {
    return iterator(data + N);
  }
  
  // index operatorok
  const T& operator[](size_t i) const {
    if (N <= i)
      throw exception();
    return data[i];
  }
  T& operator[](size_t i) {
    if (N <= i)
      throw exception();
    return data[i];
  }
};

// vektor feltoltese veletlen elemekkel
template<class T, size_t N>
void init(Vector<T,N>& v) {
  /*for (auto it = v.begin(); it != v.end(); ++it)
    *it = rand() % 100;*/
  for (auto &it : v)
    it = rand() % 100;
}

// vektor kiiratasara szolgalo függveny
template<class T, size_t N>
void print(const string& s, Vector<T,N>& v) {
#if 0
  cout << s;
  for (auto it = --(v.end()); it != --(v.begin()); it--)
    cout << *it  << " ";
  cout << endl;
#endif

#if 0
  cout << s;
  for (auto it = v.rbegin(); it != v.rend(); it++)
    cout << *it  << " ";
  cout << endl;
#endif

  cout << s;
  // eredeti sorrend
  for (const auto &it : v)
    cout << it << " ";
  cout << endl;
}

int main() {
  srand(time(nullptr));

  Vector<int,5> v;
  init(v);
  print("v = ", v);
}
