/* Írj effektort "backwards" névvel, ami stringet vár paraméterül és azt
 * fordítva írja ki a streamre.
 * pl. 
 *   cout << backwards("valami") << endl;  // -> imalav
 */

#include <iostream>
#include <string>

using namespace std;

class backwards {
  string s;
public:
  backwards(const string& s) : s(s) {
  }

  friend ostream& operator<<(ostream &os, const backwards &b) {
    for (string::const_reverse_iterator rit = b.s.rbegin(); rit != b.s.rend(); ++rit)
      os << *rit;
    return os;
  }
};

int main() {
  cout << backwards("valami") << endl;
}
